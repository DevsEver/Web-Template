(function ($){
    "use strict";
        
        /*==============================================
	NAVIGATION
	===============================================*/
	$('a.page-scroll').on('click', function(e){
		var anchor = $(this);
		$('html, body').stop().animate({
			scrollTop: $(anchor.attr('href')).offset().top - 50
		}, 1500);
		e.preventDefault();
	});		

	$(window).on('scroll', function() {
		var menuTop = $('.menu-top');
		if ($(this).scrollTop() > 100) {
			menuTop.addClass('menu-shrink');
		} else {
			menuTop.removeClass('menu-shrink');
		}
	});			
	
	$(document).on('click','.navbar-collapse.in',function(e) {
		if( $(e.target).is('a') && $(e.target).attr('class') != 'dropdown-toggle' ) {
			$(this).collapse('hide');
		}
	});
        
      
        /*==============================================
	NAVIGATION End
	===============================================*/
    
/*==============================================
	SLIDER ANIMATION
	===============================================*/
	//Function to animate slider captions 
    function doAnimations( elems ) {
        //Cache the animationend event in a variable
        var animEndEv = 'webkitAnimationEnd animationend';
        
        elems.each(function () {
            var $this = $(this),
                $animationType = $this.data('animation');
            $this.addClass($animationType).one(animEndEv, function () {
                $this.removeClass($animationType);
            });
        });
    }
    
    //Variables on page load 
    var $myCarousel = $('#carousel-example-generic'),
        $firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
        
    //Initialize carousel 
    $myCarousel.carousel();
    
    //Animate captions in first slide on page load 
    doAnimations($firstAnimatingElems);
    
    //Pause carousel  
    $myCarousel.carousel('pause');
    
    
    //Other slides to be animated on carousel slide event 
    $myCarousel.on('slide.bs.carousel', function (e) {
        var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
        doAnimations($animatingElems);
    });  
/*==============================================
	SLIDER ANIMATION End
	===============================================*/
    
    /*==============================================
	SKILL BAR
	===============================================*/
    $('.skillbar').each(function(){
		$(this).find('.skillbar-bar').animate({
			width:$(this).attr('data-percent')
		},6000);
	});
    
    /*==============================================
	MIXITUP
	===============================================*/
	jQuery('.grid').mixitup({
			targetSelector: '.mix',
		});
		$('.image-popup').magnificPopup({
			type: 'image',
			closeOnContentClick: true,
			mainClass: 'mfp-img-mobile',
			image: {
				verticalFit: true
			}
		});

     /*==============================================
	 Client Testimonials
	===============================================*/
  
        $(".testimonial-carousel").owlCarousel({
		  items:3,
		  autolay:false,
		  nav:false,
		  loop:true,
		  dots:true,
		     responsive:{
                  0: {
                        items: 1
                    },
                    480: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 3
                    },
                    1200: {
                        items: 3
                    }
              }
	  });
}(jQuery));
